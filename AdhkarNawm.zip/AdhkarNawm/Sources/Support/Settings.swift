import SwiftUI
import UserNotifications

// MARK: - Preferences

enum ThemeMode: String, CaseIterable, Identifiable {
    case system, light, dark, night
    var id: String { rawValue }
}

enum NumeralStyle: String, CaseIterable, Identifiable {
    case arabic, western
    var id: String { rawValue }
}

enum AppLanguage: String, CaseIterable, Identifiable {
    case ar, fr
    var id: String { rawValue }
}

/// User-selectable colour of the Arabic text.
enum TextTint: String, CaseIterable, Identifiable {
    case gold, white, mint, rose, sky, amber
    var id: String { rawValue }

    /// Colour on dark backgrounds.
    var dark: Color {
        switch self {
        case .gold:  return Color(hex: "#F4DFAE")
        case .white: return Color(hex: "#F5F5F7")
        case .mint:  return Color(hex: "#9FE8C5")
        case .rose:  return Color(hex: "#FFB3CE")
        case .sky:   return Color(hex: "#A9D6FF")
        case .amber: return Color(hex: "#FFC27A")
        }
    }
    /// Colour on the light background (deeper so it stays readable).
    var light: Color {
        switch self {
        case .gold:  return Color(hex: "#7A5A00")
        case .white: return Color(hex: "#1C1C1E")
        case .mint:  return Color(hex: "#0B7A55")
        case .rose:  return Color(hex: "#B01E57")
        case .sky:   return Color(hex: "#0A5FB4")
        case .amber: return Color(hex: "#A65400")
        }
    }
}

@MainActor
final class AppSettings: ObservableObject {
    @Published var theme: ThemeMode { didSet { save(theme.rawValue, "theme") } }
    @Published var numerals: NumeralStyle { didSet { save(numerals.rawValue, "numerals") } }
    @Published var language: AppLanguage { didSet { save(language.rawValue, "language") } }
    @Published var tint: TextTint { didSet { save(tint.rawValue, "tint") } }
    @Published var fontSize: Double { didSet { save(fontSize, "fontSize") } }
    @Published var haptics: Bool { didSet { save(haptics, "haptics") } }
    @Published var autoAdvance: Bool { didSet { save(autoAdvance, "autoAdvance") } }
    @Published var reminderOn: Bool { didSet { save(reminderOn, "reminderOn") } }
    @Published var reminderHour: Int { didSet { save(reminderHour, "reminderHour") } }
    @Published var reminderMinute: Int { didSet { save(reminderMinute, "reminderMinute") } }
    @Published var onboarded: Bool { didSet { save(onboarded, "onboarded") } }

    private let d = UserDefaults.standard

    init() {
        let d = UserDefaults.standard
        theme = ThemeMode(rawValue: d.string(forKey: "theme") ?? "") ?? .night
        numerals = NumeralStyle(rawValue: d.string(forKey: "numerals") ?? "") ?? .arabic
        language = AppLanguage(rawValue: d.string(forKey: "language") ?? "") ?? .ar
        tint = TextTint(rawValue: d.string(forKey: "tint") ?? "") ?? .gold
        let fs = d.double(forKey: "fontSize")
        fontSize = fs == 0 ? 30 : fs
        haptics = d.object(forKey: "haptics") as? Bool ?? true
        autoAdvance = d.object(forKey: "autoAdvance") as? Bool ?? true
        reminderOn = d.bool(forKey: "reminderOn")
        reminderHour = d.object(forKey: "reminderHour") as? Int ?? 22
        reminderMinute = d.object(forKey: "reminderMinute") as? Int ?? 30
        onboarded = d.bool(forKey: "onboarded")
    }

    private func save(_ v: Any, _ key: String) { d.set(v, forKey: key) }

    // MARK: Derived

    var isArabic: Bool { language == .ar }
    var layoutDirection: LayoutDirection { isArabic ? .rightToLeft : .leftToRight }
    var preferredScheme: ColorScheme? {
        switch theme {
        case .system: return nil
        case .light: return .light
        case .dark, .night: return .dark
        }
    }

    func palette(_ scheme: ColorScheme) -> Palette {
        switch theme {
        case .light: return .light
        case .dark: return .dark
        case .night: return .night
        case .system: return scheme == .dark ? .dark : .light
        }
    }

    func textColor(_ p: Palette) -> Color {
        let base = p.isDark ? tint.dark : tint.light
        return p.isNight ? base.opacity(0.88) : base
    }

    // MARK: Numerals

    func num(_ n: Int) -> String {
        let s = String(n)
        guard numerals == .arabic else { return s }
        let map: [Character: Character] = ["0": "٠", "1": "١", "2": "٢", "3": "٣", "4": "٤",
                                           "5": "٥", "6": "٦", "7": "٧", "8": "٨", "9": "٩"]
        return String(s.map { map[$0] ?? $0 })
    }

    func time(_ h: Int, _ m: Int) -> String { num(h) + ":" + (m < 10 ? num(0) : "") + num(m) }

    // MARK: Strings

    func t(_ key: String) -> String {
        guard let pair = L10n.table[key] else { return key }
        return isArabic ? pair.0 : pair.1
    }

    func title(_ d: Dhikr) -> String { isArabic ? d.title : d.fr }
    func name(_ c: DhikrCategory) -> String { isArabic ? c.ar : c.fr }

    // MARK: Reminder

    func applyReminder() {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: ["bedtime"])
        guard reminderOn else { return }
        let hour = reminderHour
        let minute = reminderMinute
        let title = t("reminder.title")
        let body = t("reminder.body")
        center.requestAuthorization(options: [.alert, .sound]) { granted, _ in
            guard granted else { return }
            let content = UNMutableNotificationContent()
            content.title = title
            content.body = body
            content.sound = .default
            var comps = DateComponents()
            comps.hour = hour
            comps.minute = minute
            let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: true)
            center.add(UNNotificationRequest(identifier: "bedtime", content: content, trigger: trigger))
        }
    }
}

// MARK: - Palette

struct Palette {
    let isDark: Bool
    let isNight: Bool
    let bg: Color
    let surface: Color
    let surface2: Color
    let label: Color
    let secondary: Color
    let tertiary: Color
    let separator: Color
    let starOpacity: Double

    static let light = Palette(isDark: false, isNight: false,
        bg: Color(hex: "#F2F2F7"), surface: .white, surface2: Color(hex: "#F2F2F7"),
        label: Color(hex: "#1C1C1E"), secondary: Color(hex: "#6C6C70"), tertiary: Color(hex: "#AEAEB2"),
        separator: Color.black.opacity(0.08), starOpacity: 0)

    static let dark = Palette(isDark: true, isNight: false,
        bg: .black, surface: Color(hex: "#1C1C1E"), surface2: Color(hex: "#2C2C2E"),
        label: Color(hex: "#F5F5F7"), secondary: Color(hex: "#98989F"), tertiary: Color(hex: "#636366"),
        separator: Color.white.opacity(0.09), starOpacity: 1)

    /// Warm, low-blue palette for reading in a dark bedroom.
    static let night = Palette(isDark: true, isNight: true,
        bg: Color(hex: "#070508"), surface: Color(hex: "#15100F"), surface2: Color(hex: "#211916"),
        label: Color(hex: "#E8D5B5"), secondary: Color(hex: "#A08C72"), tertiary: Color(hex: "#6B5C4A"),
        separator: Color(hex: "#E8D5B5").opacity(0.09), starOpacity: 0.7)
}

// MARK: - Localised UI strings (Arabic, French)

enum L10n {
    static let table: [String: (String, String)] = [
        "app.name": ("أذكار النوم", "Adhkâr du sommeil"),
        "home.tonight": ("ليلتك", "Cette nuit"),
        "home.flow": ("ابدأ تدفق النوم", "Lancer le Flux du sommeil"),
        "home.flow.sub": ("مرِّر لأعلى، واعدّ بلمسة، وانظر السماء تظلم", "Glissez, comptez d'un tap, regardez le ciel s'assombrir"),
        "home.categories": ("الأبواب", "Rubriques"),
        "home.favorites": ("المفضلة", "Favoris"),
        "home.search": ("ابحث في الأذكار", "Rechercher"),
        "home.count": ("ذكرًا", "invocations"),
        "home.streak": ("ليالٍ متتالية", "nuits de suite"),
        "tab.home": ("الرئيسية", "Accueil"),
        "tab.favorites": ("المفضلة", "Favoris"),
        "tab.settings": ("الإعدادات", "Réglages"),
        "tab.search": ("بحث", "Recherche"),
        "detail.virtue": ("الفضل", "Mérite"),
        "detail.source": ("المصدر", "Source"),
        "detail.tap": ("اضغط للعدّ", "Touchez pour compter"),
        "detail.done": ("تمّ", "Terminé"),
        "detail.remaining": ("المتبقي", "Restant"),
        "flow.next": ("مرِّر للتالي", "Glissez pour continuer"),
        "flow.end.title": ("تصبح على خير", "Bonne nuit"),
        "flow.end.sub": ("تقبّل الله منا ومنكم", "Qu'Allah accepte de nous et de vous"),
        "flow.close": ("إغلاق", "Fermer"),
        "flow.choose": ("اختر ما تريد في تدفقك", "Choisissez votre flux"),
        "flow.all": ("كل الأذكار", "Tout"),
        "flow.short": ("نسخة قصيرة", "Version courte"),
        "settings.appearance": ("المظهر", "Apparence"),
        "settings.theme": ("الثيم", "Thème"),
        "theme.system": ("تلقائي", "Auto"),
        "theme.light": ("فاتح", "Clair"),
        "theme.dark": ("داكن", "Sombre"),
        "theme.night": ("ليلي", "Nuit"),
        "settings.textcolor": ("لون الكتابة", "Couleur du texte"),
        "tint.gold": ("ذهبي", "Or"),
        "tint.white": ("أبيض", "Blanc"),
        "tint.mint": ("نعناعي", "Menthe"),
        "tint.rose": ("وردي", "Rose"),
        "tint.sky": ("سماوي", "Ciel"),
        "tint.amber": ("عنبري", "Ambre"),
        "settings.fontsize": ("حجم الخط", "Taille du texte"),
        "settings.numerals": ("الأرقام", "Chiffres"),
        "numerals.arabic": ("عربية ١٢٣", "Arabes ١٢٣"),
        "numerals.western": ("غربية 123", "Occidentaux 123"),
        "settings.language": ("لغة الواجهة", "Langue"),
        "settings.behavior": ("السلوك", "Comportement"),
        "settings.haptics": ("الاهتزاز اللمسي", "Retour haptique"),
        "settings.autoadvance": ("الانتقال التلقائي عند الإتمام", "Passage automatique"),
        "settings.reminder": ("تذكير قبل النوم", "Rappel du soir"),
        "settings.reminder.time": ("وقت التذكير", "Heure du rappel"),
        "settings.about": ("عن التطبيق", "À propos"),
        "settings.reset": ("إعادة تقدّم الليلة", "Réinitialiser la nuit"),
        "settings.verify": ("الأحاديث مخرّجة بمصادرها. ويُنصح بمراجعة النص القرآني على المصحف.", "Les hadiths sont référencés. Vérifiez le texte coranique sur un mushaf."),
        "about.made": ("صُنع بواسطة", "Créé par"),
        "about.name": ("زكريا جبلي", "Zakaria Jabali"),
        "grade.صحيح": ("صحيح", "Authentique"),
        "grade.حسن": ("حسن", "Bon"),
        "grade.قرآن": ("قرآن", "Coran"),
        "onb.title": ("أذكار النوم", "Adhkâr du sommeil"),
        "onb.sub": ("أحاديث صحيحة وآيات كريمة، بتصميم هادئ يرافقك إلى النوم", "Hadiths authentiques et versets, dans un design apaisant"),
        "onb.cta": ("ابدأ", "Commencer"),
        "reminder.title": ("حان وقت أذكار النوم", "C'est l'heure des adhkâr"),
        "reminder.body": ("خذ دقيقتين قبل النوم", "Prenez deux minutes avant de dormir"),
        "empty.fav": ("لا توجد أذكار مفضلة بعد. اضغط على القلب في أي ذكر.", "Aucun favori. Touchez le cœur sur une invocation."),
        "empty.search": ("لا نتائج", "Aucun résultat"),
        "done.tonight": ("أتممت الليلة", "Terminé ce soir"),
    ]
}
