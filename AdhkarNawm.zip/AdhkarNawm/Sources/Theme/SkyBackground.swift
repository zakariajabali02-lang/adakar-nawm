import SwiftUI

// MARK: - Animated sky (mesh gradient + twinkling stars + occasional shooting star)

struct SkyBackground: View {
    var color1: Color = Color(hex: "#5e5ce6")
    var color2: Color = Color(hex: "#7d3fd1")
    /// 0 = full colour, 1 = fully dark. Used by the Sleep Flow to dim the sky as you progress.
    var dim: Double = 0

    @EnvironmentObject private var settings: AppSettings
    @Environment(\.colorScheme) private var scheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        let p = settings.palette(scheme)
        ZStack {
            p.bg
            TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: reduceMotion)) { tl in
                let t = reduceMotion ? 0 : tl.date.timeIntervalSinceReferenceDate
                MeshGradient(width: 3, height: 3,
                             points: Self.points(t),
                             colors: Self.colors(c1: color1, c2: color2, bg: p.bg, dark: p.isDark))
                    .opacity(meshOpacity(p) * (1 - 0.85 * dim))
                    .blur(radius: 20)
            }
            if p.starOpacity > 0 {
                StarField(opacity: p.starOpacity * (1 - 0.35 * dim), still: reduceMotion)
            }
        }
        .ignoresSafeArea()
        .animation(.easeInOut(duration: 1.2), value: dim)
    }

    private func meshOpacity(_ p: Palette) -> Double {
        if !p.isDark { return 0.22 }
        return p.isNight ? 0.42 : 0.62
    }

    private static func points(_ t: Double) -> [SIMD2<Float>] {
        func w(_ a: Double, _ s: Double, _ amp: Float) -> Float { Float(sin(t * s + a)) * amp }
        return [
            SIMD2(0, 0), SIMD2(0.5 + w(0.0, 0.40, 0.08), 0), SIMD2(1, 0),
            SIMD2(0, 0.5 + w(1.2, 0.35, 0.08)),
            SIMD2(0.5 + w(2.1, 0.30, 0.14), 0.5 + w(0.7, 0.33, 0.14)),
            SIMD2(1, 0.5 + w(3.3, 0.28, 0.08)),
            SIMD2(0, 1), SIMD2(0.5 + w(4.4, 0.37, 0.08), 1), SIMD2(1, 1),
        ]
    }

    private static func colors(c1: Color, c2: Color, bg: Color, dark: Bool) -> [Color] {
        if dark {
            return [c1, c2.opacity(0.7), bg,
                    c2.opacity(0.8), c1.opacity(0.9), c2.opacity(0.5),
                    bg, c1.opacity(0.35), bg]
        }
        return [c1, c2, c1.opacity(0.5),
                c2.opacity(0.6), c1, c2.opacity(0.6),
                c1.opacity(0.4), c2.opacity(0.5), c1.opacity(0.3)]
    }
}

struct StarField: View {
    let opacity: Double
    var still: Bool = false

    private struct Star { let x, y, r, base, speed, phase: Double }

    private static let stars: [Star] = {
        var seed: UInt64 = 0x9E3779B97F4A7C15
        func rnd() -> Double {
            seed = seed &* 6364136223846793005 &+ 1442695040888963407
            return Double((seed >> 33) & 0xFFFFFF) / Double(0xFFFFFF)
        }
        return (0..<70).map { _ in
            Star(x: rnd(), y: rnd() * 0.85, r: 0.8 + rnd() * 1.8, base: 0.35 + rnd() * 0.65,
                 speed: 0.6 + rnd() * 2.2, phase: rnd() * 6.28)
        }
    }()

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 24.0, paused: still)) { tl in
            Canvas { ctx, size in
                let t = still ? 0 : tl.date.timeIntervalSinceReferenceDate
                for s in Self.stars {
                    let tw = 0.5 + 0.5 * sin(t * s.speed + s.phase)
                    let rect = CGRect(x: s.x * size.width, y: s.y * size.height, width: s.r, height: s.r)
                    ctx.fill(Path(ellipseIn: rect),
                             with: .color(.white.opacity(s.base * (0.25 + 0.75 * tw) * opacity)))
                }
                // A shooting star every ~11 seconds.
                if !still {
                    let cycle = t.truncatingRemainder(dividingBy: 11.0)
                    if cycle < 1.1 {
                        let k = cycle / 1.1
                        let start = CGPoint(x: size.width * (0.95 - 0.45 * k), y: size.height * (0.06 + 0.20 * k))
                        let tail = CGPoint(x: start.x + 46, y: start.y - 18)
                        var path = Path()
                        path.move(to: start)
                        path.addLine(to: tail)
                        ctx.stroke(path, with: .linearGradient(
                            Gradient(colors: [.white.opacity(0.9 * opacity * (1 - k)), .clear]),
                            startPoint: start, endPoint: tail), lineWidth: 1.6)
                    }
                }
            }
        }
        .allowsHitTesting(false)
    }
}
