import SwiftUI
import UIKit
import CoreText

/// Registers every .ttf/.otf found in the app bundle (drop Amiri / Amiri Quran into Resources/Fonts).
enum FontLoader {
    static func registerBundledFonts() {
        for ext in ["ttf", "otf"] {
            Bundle.main.urls(forResourcesWithExtension: ext, subdirectory: nil)?.forEach {
                CTFontManagerRegisterFontsForURL($0 as CFURL, .process, nil)
            }
        }
    }
}

/// Arabic typography. Bundle the OFL fonts "Amiri Quran" and "Amiri" (see README) for the best result;
/// when they are missing the system serif/Arabic fonts are used instead.
enum ArabicFont {
    private static func has(_ name: String) -> Bool { UIFont(name: name, size: 12) != nil }

    /// Uthmani Quran text.
    static func quran(_ size: CGFloat) -> Font {
        has("AmiriQuran-Regular") ? .custom("AmiriQuran-Regular", fixedSize: size)
                                  : .system(size: size, weight: .regular, design: .serif)
    }

    /// Hadith text.
    static func hadith(_ size: CGFloat, bold: Bool = false) -> Font {
        let name = bold ? "Amiri-Bold" : "Amiri-Regular"
        return has(name) ? .custom(name, fixedSize: size)
                         : .system(size: size, weight: bold ? .bold : .regular, design: .serif)
    }
}

extension Font {
    /// Rounded, Apple-style UI font that follows Dynamic Type.
    static func ui(_ style: Font.TextStyle, weight: Font.Weight = .regular) -> Font {
        .system(style, design: .default, weight: weight)
    }
}
