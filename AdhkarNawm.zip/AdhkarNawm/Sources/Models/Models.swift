import SwiftUI

// MARK: - Content models (loaded from Resources/adhkar.json)

struct DhikrCategory: Identifiable, Codable, Hashable {
    let id: Int
    let ar: String
    let fr: String
    let sym: String
    let c1: String
    let c2: String

    var color1: Color { Color(hex: c1) }
    var color2: Color { Color(hex: c2) }
    var gradient: LinearGradient {
        LinearGradient(colors: [color1, color2], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
}

struct DhikrPart: Codable, Hashable {
    let t: String
    let n: Int
}

struct Dhikr: Identifiable, Codable, Hashable {
    let id: String
    let cat: Int
    let title: String
    let fr: String
    let text: String
    let virtue: String
    let source: String
    let grade: String
    let countText: String
    let repeatCount: Int
    let note: String
    let quran: Bool
    let parts: [DhikrPart]

    enum CodingKeys: String, CodingKey {
        case id, cat, title, fr, text, virtue, source, grade, countText
        case repeatCount = "repeat"
        case note, quran, parts
    }

    /// Total number of taps needed to complete this dhikr.
    var totalTaps: Int { parts.isEmpty ? max(1, repeatCount) : parts.map(\.n).reduce(0, +) }
}

private struct Bundle_Payload: Codable {
    let categories: [DhikrCategory]
    let items: [Dhikr]
}

// MARK: - Store (content + favourites + progress)

@MainActor
final class AdhkarStore: ObservableObject {
    let categories: [DhikrCategory]
    let items: [Dhikr]

    @Published private(set) var favorites: Set<String>
    @Published private(set) var doneTonight: Set<String>
    @Published private(set) var streak: Int

    private let defaults = UserDefaults.standard
    private let favKey = "favorites.v1"
    private let doneKey = "done.v1"
    private let doneDayKey = "done.day.v1"
    private let streakKey = "streak.v1"
    private let lastNightKey = "streak.last.v1"

    init() {
        var cats: [DhikrCategory] = []
        var its: [Dhikr] = []
        if let url = Bundle.main.url(forResource: "adhkar", withExtension: "json"),
           let data = try? Data(contentsOf: url),
           let payload = try? JSONDecoder().decode(Bundle_Payload.self, from: data) {
            cats = payload.categories
            its = payload.items
        }
        categories = cats
        items = its
        favorites = Set(UserDefaults.standard.stringArray(forKey: "favorites.v1") ?? [])
        streak = UserDefaults.standard.integer(forKey: "streak.v1")

        // "Tonight" progress resets each calendar day.
        let today = Self.dayStamp(Date())
        if UserDefaults.standard.string(forKey: "done.day.v1") == today {
            doneTonight = Set(UserDefaults.standard.stringArray(forKey: "done.v1") ?? [])
        } else {
            doneTonight = []
        }
        expireStreakIfNeeded()
    }

    func category(_ id: Int) -> DhikrCategory? { categories.first { $0.id == id } }
    func items(in category: Int) -> [Dhikr] { items.filter { $0.cat == category } }

    // Favourites
    func isFavorite(_ d: Dhikr) -> Bool { favorites.contains(d.id) }
    func toggleFavorite(_ d: Dhikr) {
        if favorites.contains(d.id) { favorites.remove(d.id) } else { favorites.insert(d.id) }
        defaults.set(Array(favorites), forKey: favKey)
    }

    // Progress
    func isDone(_ d: Dhikr) -> Bool { doneTonight.contains(d.id) }
    func markDone(_ d: Dhikr) {
        doneTonight.insert(d.id)
        defaults.set(Array(doneTonight), forKey: doneKey)
        defaults.set(Self.dayStamp(Date()), forKey: doneDayKey)
    }
    func resetTonight() {
        doneTonight = []
        defaults.set([String](), forKey: doneKey)
    }

    /// Call when the user completes a full Sleep Flow session.
    func completeNight() {
        let today = Self.dayStamp(Date())
        let last = defaults.string(forKey: lastNightKey)
        if last == today { return }
        let yesterday = Self.dayStamp(Calendar.current.date(byAdding: .day, value: -1, to: Date()) ?? Date())
        streak = (last == yesterday) ? streak + 1 : 1
        defaults.set(streak, forKey: streakKey)
        defaults.set(today, forKey: lastNightKey)
    }

    private func expireStreakIfNeeded() {
        guard let last = defaults.string(forKey: lastNightKey) else { return }
        let today = Self.dayStamp(Date())
        let yesterday = Self.dayStamp(Calendar.current.date(byAdding: .day, value: -1, to: Date()) ?? Date())
        if last != today && last != yesterday {
            streak = 0
            defaults.set(0, forKey: streakKey)
        }
    }

    private static func dayStamp(_ date: Date) -> String {
        let c = Calendar.current.dateComponents([.year, .month, .day], from: date)
        return "\(c.year ?? 0)-\(c.month ?? 0)-\(c.day ?? 0)"
    }
}

// MARK: - Color helper

extension Color {
    init(hex: String) {
        var s = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        if s.count == 3 { s = s.map { "\($0)\($0)" }.joined() }
        var v: UInt64 = 0
        Scanner(string: s).scanHexInt64(&v)
        self.init(.sRGB,
                  red: Double((v >> 16) & 0xFF) / 255,
                  green: Double((v >> 8) & 0xFF) / 255,
                  blue: Double(v & 0xFF) / 255,
                  opacity: 1)
    }
}
