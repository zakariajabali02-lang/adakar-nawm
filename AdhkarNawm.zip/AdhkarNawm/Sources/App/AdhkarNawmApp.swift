import SwiftUI

@main
struct AdhkarNawmApp: App {
    @StateObject private var settings = AppSettings()
    @StateObject private var store = AdhkarStore()

    init() { FontLoader.registerBundledFonts() }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(settings)
                .environmentObject(store)
                .environment(\.layoutDirection, settings.layoutDirection)
                .environment(\.locale, Locale(identifier: settings.isArabic ? "ar" : "fr"))
                .preferredColorScheme(settings.preferredScheme)
                .tint(Color(hex: "#5e5ce6"))
                .onAppear { settings.applyReminder() }
        }
    }
}
