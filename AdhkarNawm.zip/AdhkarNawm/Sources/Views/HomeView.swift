import SwiftUI

struct FlowSession: Identifiable {
    let id = UUID()
    let items: [Dhikr]
}

struct HomeView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var store: AdhkarStore
    @Environment(\.colorScheme) private var scheme
    @Namespace private var ns

    @State private var session: FlowSession?
    @State private var showPicker = false

    private let columns = [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)]

    var body: some View {
        let p = settings.palette(scheme)
        NavigationStack {
            ZStack {
                SkyBackground()
                ScrollView {
                    VStack(spacing: 22) {
                        header(p)
                        flowHero
                        categoryGrid
                        footer(p)
                    }
                    .padding(.horizontal, 18)
                    .padding(.bottom, 30)
                }
                .scrollIndicators(.hidden)
            }
            .navigationTitle(settings.t("app.name"))
            .navigationBarTitleDisplayMode(.large)
            .toolbarBackground(.hidden, for: .navigationBar)
            .navigationDestination(for: DhikrCategory.self) { cat in
                CategoryView(category: cat)
                    .navigationTransition(.zoom(sourceID: cat.id, in: ns))
            }
        }
        .fullScreenCover(item: $session) { s in
            FlowView(items: s.items)
                .navigationTransition(.zoom(sourceID: "flow", in: ns))
        }
        .sheet(isPresented: $showPicker) {
            FlowPickerSheet { items in
                showPicker = false
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { session = FlowSession(items: items) }
            }
            .presentationDetents([.medium])
            .presentationDragIndicator(.visible)
            .presentationCornerRadius(34)
            #if IOS27_SDK
            .navigationTransition(.crossFade)
            #endif
        }
    }

    // MARK: Header (streak + tonight progress)

    private func header(_ p: Palette) -> some View {
        let done = store.doneTonight.count
        let total = store.items.count
        return HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text(settings.t("home.tonight"))
                    .font(.ui(.footnote, weight: .semibold)).foregroundStyle(p.secondary)
                HStack(spacing: 6) {
                    Text("\(settings.num(done)) / \(settings.num(total))")
                        .font(.system(.title2, design: .rounded, weight: .bold))
                        .monospacedDigit()
                        .contentTransition(.numericText())
                    Text(settings.t("home.count")).font(.ui(.footnote)).foregroundStyle(p.secondary)
                }
                .foregroundStyle(p.label)
            }
            Spacer()
            if store.streak > 0 {
                Pill(text: "\(settings.num(store.streak)) \(settings.t("home.streak"))", icon: "flame.fill", color: .orange)
            }
        }
        .padding(18)
        .frame(maxWidth: .infinity)
        .cardSurface(radius: 24)
    }

    // MARK: Sleep Flow hero

    private var flowHero: some View {
        Button { showPicker = true } label: {
            ZStack(alignment: .leading) {
                TimelineView(.animation(minimumInterval: 1.0 / 30.0)) { tl in
                    let t = tl.date.timeIntervalSinceReferenceDate
                    MeshGradient(width: 3, height: 3, points: [
                        [0, 0], [0.5, 0], [1, 0],
                        [0, 0.5], [Float(0.5 + 0.18 * sin(t * 0.6)), Float(0.5 + 0.18 * cos(t * 0.5))], [1, 0.5],
                        [0, 1], [0.5, 1], [1, 1]
                    ], colors: [
                        Color(hex: "#7d3fd1"), Color(hex: "#5e5ce6"), Color(hex: "#0a84ff"),
                        Color(hex: "#b57bff"), Color(hex: "#5e5ce6"), Color(hex: "#7fdcff"),
                        Color(hex: "#2d1b69"), Color(hex: "#7d3fd1"), Color(hex: "#5e5ce6")
                    ])
                }
                StarField(opacity: 0.9)
                HStack(spacing: 16) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text(settings.t("home.flow"))
                            .font(.ui(.title2, weight: .bold)).foregroundStyle(.white)
                            .multilineTextAlignment(.leading)
                        Text(settings.t("home.flow.sub"))
                            .font(.ui(.footnote)).foregroundStyle(.white.opacity(0.82))
                            .multilineTextAlignment(.leading)
                    }
                    Spacer(minLength: 8)
                    Image(systemName: "play.fill")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundStyle(Color(hex: "#5e5ce6"))
                        .frame(width: 56, height: 56)
                        .background(.white, in: Circle())
                        .shadow(color: .black.opacity(0.25), radius: 10, y: 4)
                        .symbolEffect(.pulse)
                }
                .padding(22)
            }
            .frame(height: 150)
            .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 30, style: .continuous).strokeBorder(.white.opacity(0.25), lineWidth: 1))
            .shadow(color: Color(hex: "#5e5ce6").opacity(0.45), radius: 24, y: 12)
        }
        .buttonStyle(PressableStyle())
        .matchedTransitionSource(id: "flow", in: ns)
        .sensoryFeedback(.impact(flexibility: .soft), trigger: showPicker)
    }

    // MARK: Categories

    private var categoryGrid: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(settings.t("home.categories"))
                .font(.ui(.title3, weight: .bold))
                .padding(.horizontal, 4)
            LazyVGrid(columns: columns, spacing: 14) {
                ForEach(store.categories) { cat in
                    NavigationLink(value: cat) {
                        CategoryCard(category: cat, count: store.items(in: cat.id).count)
                    }
                    .buttonStyle(PressableStyle())
                    .matchedTransitionSource(id: cat.id, in: ns)
                    .scrollTransition(.animated(.snappy)) { c, phase in
                        c.opacity(phase.isIdentity ? 1 : 0.35)
                            .scaleEffect(phase.isIdentity ? 1 : 0.92)
                    }
                }
            }
        }
    }

    private func footer(_ p: Palette) -> some View {
        VStack(spacing: 4) {
            Text(settings.t("about.made")).font(.ui(.caption)).foregroundStyle(p.tertiary)
            Text(settings.t("about.name")).font(.ui(.subheadline, weight: .semibold)).foregroundStyle(p.secondary)
        }
        .padding(.top, 8)
    }
}

// MARK: - Category card

struct CategoryCard: View {
    let category: DhikrCategory
    let count: Int
    @EnvironmentObject private var settings: AppSettings

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Image(systemName: category.sym)
                .font(.system(size: 22, weight: .semibold))
                .foregroundStyle(.white)
                .frame(width: 44, height: 44)
                .background(.white.opacity(0.22), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            Spacer(minLength: 18)
            Text(settings.name(category))
                .font(.ui(.headline, weight: .bold))
                .foregroundStyle(.white)
                .multilineTextAlignment(.leading)
                .lineLimit(2)
                .minimumScaleFactor(0.85)
            Text("\(settings.num(count)) \(settings.t("home.count"))")
                .font(.ui(.caption, weight: .medium))
                .foregroundStyle(.white.opacity(0.82))
                .padding(.top, 2)
        }
        .padding(16)
        .frame(maxWidth: .infinity, minHeight: 132, alignment: .leading)
        .background(category.gradient, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).strokeBorder(.white.opacity(0.22), lineWidth: 0.8))
        .shadow(color: category.color2.opacity(0.4), radius: 14, y: 8)
    }
}

// MARK: - Button style with a springy press

struct PressableStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.965 : 1)
            .animation(.spring(response: 0.28, dampingFraction: 0.65), value: configuration.isPressed)
    }
}
