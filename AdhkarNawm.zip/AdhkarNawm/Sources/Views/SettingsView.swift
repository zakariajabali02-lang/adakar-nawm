import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var store: AdhkarStore
    @Environment(\.colorScheme) private var scheme
    @State private var confirmReset = false

    var body: some View {
        let p = settings.palette(scheme)
        NavigationStack {
            ZStack {
                SkyBackground()
                ScrollView {
                    VStack(spacing: 22) {
                        group(settings.t("settings.appearance")) {
                            themePicker(p)
                            Divider().overlay(p.separator)
                            tintPicker(p)
                            Divider().overlay(p.separator)
                            fontSizeRow(p)
                            Divider().overlay(p.separator)
                            preview(p)
                        }
                        group(settings.t("settings.numerals")) {
                            Picker("", selection: $settings.numerals) {
                                ForEach(NumeralStyle.allCases) { Text(settings.t("numerals." + $0.rawValue)).tag($0) }
                            }
                            .pickerStyle(.segmented)
                        }
                        group(settings.t("settings.language")) {
                            Picker("", selection: $settings.language) {
                                Text("العربية").tag(AppLanguage.ar)
                                Text("Français").tag(AppLanguage.fr)
                            }
                            .pickerStyle(.segmented)
                        }
                        group(settings.t("settings.behavior")) {
                            Toggle(settings.t("settings.haptics"), isOn: $settings.haptics)
                            Divider().overlay(p.separator)
                            Toggle(settings.t("settings.autoadvance"), isOn: $settings.autoAdvance)
                            Divider().overlay(p.separator)
                            Toggle(settings.t("settings.reminder"), isOn: $settings.reminderOn)
                            if settings.reminderOn {
                                DatePicker(settings.t("settings.reminder.time"), selection: reminderDate,
                                           displayedComponents: .hourAndMinute)
                                    .transition(.opacity.combined(with: .move(edge: .top)))
                            }
                        }
                        .animation(.snappy, value: settings.reminderOn)

                        aboutCard(p)

                        Button(role: .destructive) { confirmReset = true } label: {
                            Text(settings.t("settings.reset")).font(.ui(.body, weight: .medium)).frame(maxWidth: .infinity)
                        }
                        .padding(14).cardSurface(radius: 18)
                        .confirmationDialog(settings.t("settings.reset"), isPresented: $confirmReset, titleVisibility: .visible) {
                            Button(settings.t("settings.reset"), role: .destructive) { store.resetTonight() }
                        }
                    }
                    .padding(.horizontal, 18).padding(.bottom, 30)
                }
                .scrollIndicators(.hidden)
            }
            .navigationTitle(settings.t("tab.settings"))
            .toolbarBackground(.hidden, for: .navigationBar)
            .onChange(of: settings.reminderOn) { _, _ in settings.applyReminder() }
            .onChange(of: settings.reminderHour) { _, _ in settings.applyReminder() }
            .onChange(of: settings.reminderMinute) { _, _ in settings.applyReminder() }
        }
    }

    // MARK: Group container

    private func group<Content: View>(_ title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title).font(.ui(.footnote, weight: .semibold)).foregroundStyle(.secondary).padding(.horizontal, 8)
            VStack(spacing: 14) { content() }
                .padding(16).frame(maxWidth: .infinity).cardSurface(radius: 24)
        }
    }

    // MARK: Theme

    private func themePicker(_ p: Palette) -> some View {
        HStack(spacing: 10) {
            ForEach(ThemeMode.allCases) { mode in
                let sel = settings.theme == mode
                Button { withAnimation(.snappy) { settings.theme = mode } } label: {
                    VStack(spacing: 8) {
                        ThemeSwatch(mode: mode)
                            .frame(height: 58)
                            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .strokeBorder(sel ? Color.accentColor : p.separator, lineWidth: sel ? 3 : 1))
                            .scaleEffect(sel ? 1.04 : 1)
                        Text(settings.t("theme." + mode.rawValue))
                            .font(.ui(.caption, weight: sel ? .bold : .regular))
                            .foregroundStyle(sel ? Color.accentColor : p.secondary)
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .sensoryFeedback(.selection, trigger: settings.theme)
    }

    // MARK: Text colour

    private func tintPicker(_ p: Palette) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(settings.t("settings.textcolor")).font(.ui(.subheadline, weight: .medium)).foregroundStyle(p.label)
            HStack(spacing: 12) {
                ForEach(TextTint.allCases) { t in
                    let sel = settings.tint == t
                    Button { withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) { settings.tint = t } } label: {
                        Circle().fill(p.isDark ? t.dark : t.light)
                            .frame(width: 34, height: 34)
                            .overlay(Circle().strokeBorder(.white.opacity(p.isDark ? 0.9 : 0), lineWidth: sel ? 3 : 0).padding(-4))
                            .overlay(Circle().strokeBorder(p.separator, lineWidth: 1))
                            .scaleEffect(sel ? 1.12 : 1)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(settings.t("tint." + t.rawValue))
                }
            }
            .sensoryFeedback(.selection, trigger: settings.tint)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func fontSizeRow(_ p: Palette) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(settings.t("settings.fontsize")).font(.ui(.subheadline, weight: .medium)).foregroundStyle(p.label)
                Spacer()
                Text(settings.num(Int(settings.fontSize))).font(.system(.subheadline, design: .rounded, weight: .semibold))
                    .monospacedDigit().foregroundStyle(p.secondary)
            }
            Slider(value: $settings.fontSize, in: 22...48, step: 2)
        }
    }

    private func preview(_ p: Palette) -> some View {
        Text("بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ")
            .font(ArabicFont.quran(settings.fontSize))
            .foregroundStyle(settings.textColor(p))
            .environment(\.layoutDirection, .rightToLeft)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 6)
            .animation(.snappy, value: settings.fontSize)
            .animation(.snappy, value: settings.tint)
    }

    // MARK: Reminder binding

    private var reminderDate: Binding<Date> {
        Binding {
            var c = DateComponents(); c.hour = settings.reminderHour; c.minute = settings.reminderMinute
            return Calendar.current.date(from: c) ?? Date()
        } set: { d in
            let c = Calendar.current.dateComponents([.hour, .minute], from: d)
            settings.reminderHour = c.hour ?? 22
            settings.reminderMinute = c.minute ?? 30
        }
    }

    // MARK: About

    private func aboutCard(_ p: Palette) -> some View {
        VStack(spacing: 14) {
            Image(systemName: "moon.stars.fill")
                .font(.system(size: 34))
                .foregroundStyle(.white)
                .frame(width: 72, height: 72)
                .background(LinearGradient(colors: [Color(hex: "#9a98ff"), Color(hex: "#5e5ce6"), Color(hex: "#7d3fd1")],
                                           startPoint: .topLeading, endPoint: .bottomTrailing),
                            in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                .shadow(color: Color(hex: "#5e5ce6").opacity(0.5), radius: 14, y: 6)
            VStack(spacing: 2) {
                Text(settings.t("about.made")).font(.ui(.caption)).foregroundStyle(p.secondary)
                Text(settings.t("about.name")).font(.ui(.title3, weight: .bold)).foregroundStyle(p.label)
            }
            Text(settings.t("settings.verify"))
                .font(.ui(.footnote)).foregroundStyle(p.secondary).multilineTextAlignment(.center)
            Text("© 2026 Zakaria Jabali")
                .font(.ui(.caption2)).foregroundStyle(p.tertiary)
        }
        .padding(20).frame(maxWidth: .infinity).cardSurface(radius: 26)
    }
}

// MARK: - Mini preview of each theme

struct ThemeSwatch: View {
    let mode: ThemeMode
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let shape = RoundedRectangle(cornerRadius: 14, style: .continuous)
        switch mode {
        case .system:
            ZStack {
                HStack(spacing: 0) {
                    Palette.light.bg
                    Palette.dark.bg
                }
                Text("Aa").font(.system(.headline, design: .rounded, weight: .bold)).foregroundStyle(.gray)
            }
            .clipShape(shape)
        case .light: swatch(.light, Color(hex: "#7A5A00"), shape)
        case .dark: swatch(.dark, Color(hex: "#F4DFAE"), shape)
        case .night: swatch(.night, Color(hex: "#F4DFAE").opacity(0.88), shape)
        }
    }

    private func swatch(_ p: Palette, _ c: Color, _ shape: RoundedRectangle) -> some View {
        ZStack {
            p.bg
            if p.isDark { StarField(opacity: 0.8, still: true) }
            Text("Aa").font(.system(.headline, design: .rounded, weight: .bold)).foregroundStyle(c)
        }
        .clipShape(shape)
    }
}
