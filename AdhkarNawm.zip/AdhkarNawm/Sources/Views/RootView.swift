import SwiftUI

struct RootView: View {
    @EnvironmentObject private var settings: AppSettings

    var body: some View {
        ZStack {
            if settings.onboarded {
                MainTabs()
                    .transition(.opacity.combined(with: .scale(scale: 1.04)))
            } else {
                OnboardingView()
                    .transition(.opacity.combined(with: .scale(scale: 0.96)))
            }
        }
        .animation(.smooth(duration: 0.7), value: settings.onboarded)
    }
}

struct MainTabs: View {
    @EnvironmentObject private var settings: AppSettings

    var body: some View {
        TabView {
            Tab(settings.t("tab.home"), systemImage: "moon.stars.fill") { HomeView() }
            Tab(settings.t("tab.favorites"), systemImage: "heart.fill") { FavoritesView() }
            Tab(settings.t("tab.settings"), systemImage: "gearshape.fill") { SettingsView() }
            Tab(settings.t("tab.search"), systemImage: "magnifyingglass", role: .search) { SearchView() }
        }
    }
}

// MARK: - Welcome

struct OnboardingView: View {
    @EnvironmentObject private var settings: AppSettings
    @State private var appeared = false

    var body: some View {
        ZStack {
            SkyBackground(color1: Color(hex: "#5e5ce6"), color2: Color(hex: "#7d3fd1"))
            VStack(spacing: 18) {
                Spacer()
                ZStack {
                    Circle().fill(Color(hex: "#7d7aff").opacity(0.5)).frame(width: 190, height: 190).blur(radius: 40)
                        .scaleEffect(appeared ? 1.1 : 0.8)
                    Image(systemName: "moon.stars.fill")
                        .symbolRenderingMode(.palette)
                        .foregroundStyle(.white, Color(hex: "#FFE9A8"))
                        .font(.system(size: 62))
                        .frame(width: 124, height: 124)
                        .background(LinearGradient(colors: [Color(hex: "#9a98ff"), Color(hex: "#5e5ce6"), Color(hex: "#7d3fd1")],
                                                   startPoint: .topLeading, endPoint: .bottomTrailing),
                                    in: RoundedRectangle(cornerRadius: 34, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous).strokeBorder(.white.opacity(0.25), lineWidth: 1))
                        .symbolEffect(.pulse, options: .repeating)
                        .offset(y: appeared ? 0 : 14)
                }
                .opacity(appeared ? 1 : 0)

                Text(settings.t("onb.title"))
                    .font(.system(size: 44, weight: .bold)).foregroundStyle(.white)
                    .opacity(appeared ? 1 : 0).offset(y: appeared ? 0 : 16)
                Text(settings.t("onb.sub"))
                    .font(.ui(.title3)).foregroundStyle(.white.opacity(0.8)).multilineTextAlignment(.center)
                    .padding(.horizontal, 30)
                    .opacity(appeared ? 1 : 0).offset(y: appeared ? 0 : 16)

                Spacer()

                VStack(spacing: 14) {
                    Picker("", selection: $settings.language) {
                        Text("العربية").tag(AppLanguage.ar)
                        Text("Français").tag(AppLanguage.fr)
                    }.pickerStyle(.segmented)
                    Picker("", selection: $settings.numerals) {
                        ForEach(NumeralStyle.allCases) { Text(settings.t("numerals." + $0.rawValue)).tag($0) }
                    }.pickerStyle(.segmented)

                    Button { settings.onboarded = true } label: {
                        Text(settings.t("onb.cta"))
                            .font(.ui(.headline, weight: .bold)).foregroundStyle(.white)
                            .frame(maxWidth: .infinity).padding(.vertical, 16)
                            .background(Color(hex: "#0a84ff"), in: Capsule())
                    }
                    .buttonStyle(PressableStyle())
                    .sensoryFeedback(.impact(flexibility: .soft), trigger: settings.onboarded)

                    Text("\(settings.t("about.made")) \(settings.t("about.name"))")
                        .font(.ui(.caption)).foregroundStyle(.white.opacity(0.5))
                }
                .padding(.horizontal, 24).padding(.bottom, 24)
                .opacity(appeared ? 1 : 0)
            }
        }
        .preferredColorScheme(.dark)
        .onAppear { withAnimation(.spring(response: 1.1, dampingFraction: 0.8)) { appeared = true } }
    }
}
