import SwiftUI

// MARK: - App-icon style tile for a category

struct CategoryTile: View {
    let category: DhikrCategory
    var size: CGFloat = 40

    var body: some View {
        Image(systemName: category.sym)
            .font(.system(size: size * 0.46, weight: .semibold))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(category.gradient, in: RoundedRectangle(cornerRadius: size * 0.27, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: size * 0.27, style: .continuous)
                    .strokeBorder(.white.opacity(0.22), lineWidth: 0.6)
            )
            .shadow(color: category.color2.opacity(0.35), radius: size * 0.18, y: size * 0.08)
            .accessibilityHidden(true)
    }
}

// MARK: - Card surface (Liquid Glass on iOS 26+, material before that)

struct CardSurface: ViewModifier {
    var radius: CGFloat = 28
    var tint: Color? = nil
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.colorScheme) private var scheme

    func body(content: Content) -> some View {
        let p = settings.palette(scheme)
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        if #available(iOS 26.0, *) {
            content.glassEffect(tint == nil ? .regular : .regular.tint(tint!.opacity(0.18)), in: shape)
        } else {
            content
                .background(p.surface.opacity(p.isDark ? 0.82 : 1), in: shape)
                .overlay(shape.strokeBorder(p.separator, lineWidth: 1))
        }
    }
}

extension View {
    func cardSurface(radius: CGFloat = 28, tint: Color? = nil) -> some View {
        modifier(CardSurface(radius: radius, tint: tint))
    }
}

// MARK: - Small pill

struct Pill: View {
    let text: String
    var icon: String? = nil
    var color: Color
    var body: some View {
        HStack(spacing: 6) {
            if let icon { Image(systemName: icon).font(.system(size: 12, weight: .bold)) }
            Text(text).font(.ui(.footnote, weight: .semibold))
        }
        .foregroundStyle(color)
        .padding(.horizontal, 12).padding(.vertical, 6)
        .background(color.opacity(0.16), in: Capsule())
    }
}

// MARK: - Counter ring (tap to count, fills like an Activity ring)

struct CounterRing: View {
    let total: Int
    let count: Int
    var size: CGFloat = 84
    var color: Color
    var label: String           // text for the remaining number (already localised)
    var onTap: () -> Void

    @EnvironmentObject private var settings: AppSettings
    @State private var pressed = false

    private var done: Bool { count >= total }
    private var progress: Double { total == 0 ? 1 : min(1, Double(count) / Double(total)) }

    var body: some View {
        Button(action: onTap) {
            ZStack {
                Circle().fill(color.opacity(0.14))
                Circle().stroke(.white.opacity(0.10), lineWidth: 6)
                Circle()
                    .trim(from: 0, to: progress)
                    .stroke(AngularGradient(colors: [color.opacity(0.55), color], center: .center),
                            style: StrokeStyle(lineWidth: 6, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                    .scaleEffect(x: settings.isArabic ? -1 : 1)   // fill in reading direction
                    .animation(.spring(response: 0.45, dampingFraction: 0.82), value: progress)
                if done {
                    Image(systemName: "checkmark")
                        .font(.system(size: size * 0.34, weight: .bold))
                        .foregroundStyle(color)
                        .symbolEffect(.bounce, value: done)
                        .transition(.scale.combined(with: .opacity))
                } else {
                    Text(label)
                        .font(.system(size: size * 0.36, weight: .bold, design: .rounded))
                        .monospacedDigit()
                        .foregroundStyle(color)
                        .contentTransition(.numericText(countsDown: true))
                }
            }
            .frame(width: size, height: size)
            .scaleEffect(pressed ? 0.93 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.6), value: pressed)
        }
        .buttonStyle(.plain)
        .simultaneousGesture(DragGesture(minimumDistance: 0)
            .onChanged { _ in pressed = true }
            .onEnded { _ in pressed = false })
        .sensoryFeedback(trigger: count) { old, new in
            guard settings.haptics, new > old else { return nil }
            return new >= total ? .success : .impact(flexibility: .soft, intensity: 0.7)
        }
        .accessibilityLabel(done ? settings.t("detail.done") : settings.t("detail.tap"))
        .accessibilityValue("\(settings.t("detail.remaining")) \(max(0, total - count))")
    }
}
