import SwiftUI

/// One dhikr: title, Arabic text, tap counter, merit, source. Used by the detail page and the Sleep Flow.
struct DhikrCardView: View {
    let dhikr: Dhikr
    var showCategory: Bool = true
    var onComplete: () -> Void = {}

    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var store: AdhkarStore
    @Environment(\.colorScheme) private var scheme
    @State private var count = 0

    private var category: DhikrCategory? { store.category(dhikr.cat) }
    private var accent: Color { category?.color1 ?? .accentColor }

    var body: some View {
        let p = settings.palette(scheme)
        let textColor = settings.textColor(p)

        ScrollView {
            VStack(spacing: 18) {
                if showCategory, let c = category {
                    HStack(spacing: 10) {
                        CategoryTile(category: c, size: 30)
                        Text(settings.name(c))
                            .font(.ui(.subheadline, weight: .semibold))
                            .foregroundStyle(p.secondary)
                    }
                }

                Text(settings.title(dhikr))
                    .font(.ui(.title, weight: .bold))
                    .foregroundStyle(p.label)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)

                textCard(p: p, color: textColor)

                counter(p: p)

                if !dhikr.virtue.isEmpty {
                    callout(icon: "sparkles", text: dhikr.virtue, color: accent, p: p)
                }
                if !dhikr.note.isEmpty {
                    callout(icon: "info.circle", text: dhikr.note, color: p.secondary, p: p)
                }
                sourceRow(p: p)
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 24)
            .frame(maxWidth: 640)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.hidden)
        .onChange(of: dhikr.id) { _, _ in count = 0 }
    }

    // MARK: Pieces

    @ViewBuilder
    private func textCard(p: Palette, color: Color) -> some View {
        let size = settings.fontSize
        let font = dhikr.quran ? ArabicFont.quran(size) : ArabicFont.hadith(size)

        VStack(spacing: 0) {
            if dhikr.parts.isEmpty {
                Text(dhikr.text)
                    .font(font)
                    .foregroundStyle(color)
                    .lineSpacing(size * (dhikr.quran ? 0.62 : 0.5))
                    .multilineTextAlignment(.center)
                    .environment(\.layoutDirection, .rightToLeft)
                    .fixedSize(horizontal: false, vertical: true)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 6)
            } else {
                ForEach(Array(dhikr.parts.enumerated()), id: \.offset) { i, part in
                    let range = partRange(i)
                    let inPart = min(max(count - range.lowerBound, 0), part.n)
                    HStack {
                        Text(part.t)
                            .font(ArabicFont.hadith(size * 1.1, bold: true))
                            .foregroundStyle(color)
                            .environment(\.layoutDirection, .rightToLeft)
                        Spacer(minLength: 12)
                        Pill(text: inPart >= part.n ? "✓" : "\(settings.num(inPart)) / \(settings.num(part.n))",
                             color: accent)
                    }
                    .padding(.vertical, 10)
                    .opacity(inPart >= part.n ? 0.55 : 1)
                    if i < dhikr.parts.count - 1 { Divider().overlay(p.separator) }
                }
            }
        }
        .padding(.horizontal, 20).padding(.vertical, 18)
        .frame(maxWidth: .infinity)
        .cardSurface(tint: accent)
    }

    private func counter(p: Palette) -> some View {
        HStack(spacing: 16) {
            CounterRing(total: dhikr.totalTaps, count: count, size: 84, color: accent,
                        label: settings.num(max(0, dhikr.totalTaps - count))) { tap() }
            VStack(alignment: settings.isArabic ? .trailing : .leading, spacing: 2) {
                Text(count >= dhikr.totalTaps ? settings.t("detail.done") : (dhikr.countText.isEmpty ? settings.t("detail.tap") : dhikr.countText))
                    .font(.ui(.headline, weight: .bold))
                    .foregroundStyle(accent)
                if !dhikr.countText.isEmpty && count < dhikr.totalTaps {
                    Text(settings.t("detail.tap")).font(.ui(.footnote)).foregroundStyle(p.secondary)
                }
            }
        }
        .padding(.top, 2)
    }

    private func callout(icon: String, text: String, color: Color, p: Palette) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon).font(.system(size: 17, weight: .semibold)).foregroundStyle(color).padding(.top, 5)
            Text(text)
                .font(ArabicFont.hadith(settings.fontSize * 0.62))
                .foregroundStyle(color)
                .lineSpacing(6)
                .frame(maxWidth: .infinity, alignment: .leading)
                .multilineTextAlignment(settings.isArabic ? .trailing : .leading)
        }
        .padding(16)
        .background(color.opacity(0.13), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }

    private func sourceRow(p: Palette) -> some View {
        VStack(spacing: 10) {
            Pill(text: settings.t("grade." + dhikr.grade), icon: "checkmark.seal.fill",
                 color: dhikr.grade == "حسن" ? .orange : .green)
            Text(dhikr.source)
                .font(.ui(.footnote))
                .foregroundStyle(p.secondary)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.top, 4)
    }

    // MARK: Logic

    private func partRange(_ i: Int) -> Range<Int> {
        let start = dhikr.parts.prefix(i).map(\.n).reduce(0, +)
        return start..<(start + dhikr.parts[i].n)
    }

    private func tap() {
        if count >= dhikr.totalTaps {
            count = 0
            return
        }
        withAnimation(.snappy) { count += 1 }
        if count >= dhikr.totalTaps {
            store.markDone(dhikr)
            onComplete()
        }
    }
}

// MARK: - Toolbar helpers

struct DhikrToolbar: View {
    let dhikr: Dhikr
    @EnvironmentObject private var store: AdhkarStore
    @EnvironmentObject private var settings: AppSettings

    var shareText: String {
        let body = dhikr.parts.isEmpty ? dhikr.text : dhikr.parts.map { "\($0.t) × \($0.n)" }.joined(separator: "\n")
        return "\(dhikr.title)\n\n\(body)\n\n\(dhikr.source)\n— \(L10n.table["app.name"]!.0) · \(L10n.table["about.name"]!.0)"
    }

    var body: some View {
        HStack(spacing: 4) {
            ShareLink(item: shareText) { Image(systemName: "square.and.arrow.up") }
            Button { store.toggleFavorite(dhikr) } label: {
                Image(systemName: store.isFavorite(dhikr) ? "heart.fill" : "heart")
                    .symbolEffect(.bounce, value: store.isFavorite(dhikr))
                    .foregroundStyle(store.isFavorite(dhikr) ? Color.pink : Color.primary)
            }
            .sensoryFeedback(.impact(flexibility: .soft), trigger: store.isFavorite(dhikr))
        }
    }
}
