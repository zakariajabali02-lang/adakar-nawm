import SwiftUI

// MARK: - Category → list of dhikr

struct CategoryView: View {
    let category: DhikrCategory
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var store: AdhkarStore
    @Environment(\.colorScheme) private var scheme
    @Namespace private var ns

    var body: some View {
        let p = settings.palette(scheme)
        let items = store.items(in: category.id)
        ZStack {
            SkyBackground(color1: category.color1, color2: category.color2)
            ScrollView {
                LazyVStack(spacing: 12) {
                    ForEach(items) { d in
                        NavigationLink(value: d) {
                            DhikrRow(dhikr: d, category: category)
                        }
                        .buttonStyle(PressableStyle())
                        .matchedTransitionSource(id: d.id, in: ns)
                        .scrollTransition(.animated(.snappy)) { c, phase in
                            c.opacity(phase.isIdentity ? 1 : 0.4).scaleEffect(phase.isIdentity ? 1 : 0.95)
                        }
                    }
                }
                .padding(.horizontal, 18)
                .padding(.vertical, 12)
            }
            .scrollIndicators(.hidden)
        }
        .navigationTitle(settings.name(category))
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.hidden, for: .navigationBar)
        .navigationDestination(for: Dhikr.self) { d in
            DetailPager(items: items, selected: d.id)
                .navigationTransition(.zoom(sourceID: d.id, in: ns))
        }
        .tint(p.label)
    }
}

struct DhikrRow: View {
    let dhikr: Dhikr
    let category: DhikrCategory
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var store: AdhkarStore
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let p = settings.palette(scheme)
        HStack(spacing: 14) {
            CategoryTile(category: category, size: 42)
            VStack(alignment: .leading, spacing: 3) {
                Text(settings.title(dhikr))
                    .font(.ui(.body, weight: .semibold))
                    .foregroundStyle(p.label)
                    .multilineTextAlignment(.leading)
                    .lineLimit(2)
                Text(dhikr.source)
                    .font(.ui(.caption))
                    .foregroundStyle(p.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: 6)
            if store.isDone(dhikr) {
                Image(systemName: "checkmark.circle.fill").foregroundStyle(category.color1)
            }
            if store.isFavorite(dhikr) {
                Image(systemName: "heart.fill").foregroundStyle(.pink).font(.footnote)
            }
            Image(systemName: settings.isArabic ? "chevron.left" : "chevron.right")
                .font(.system(size: 13, weight: .semibold)).foregroundStyle(p.tertiary)
        }
        .padding(14)
        .frame(maxWidth: .infinity)
        .cardSurface(radius: 22)
    }
}

// MARK: - Swipe between dhikr

struct DetailPager: View {
    let items: [Dhikr]
    @State var selected: String
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var store: AdhkarStore

    init(items: [Dhikr], selected: String) {
        self.items = items
        _selected = State(initialValue: selected)
    }

    private var current: Dhikr? { items.first { $0.id == selected } }
    private var category: DhikrCategory? { current.flatMap { store.category($0.cat) } }

    var body: some View {
        ZStack {
            SkyBackground(color1: category?.color1 ?? .indigo, color2: category?.color2 ?? .purple)
            TabView(selection: $selected) {
                ForEach(items) { d in
                    DhikrCardView(dhikr: d, showCategory: false).tag(d.id)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.hidden, for: .navigationBar)
        .toolbar {
            ToolbarItem(placement: .principal) {
                if let i = items.firstIndex(where: { $0.id == selected }) {
                    Text("\(settings.num(i + 1)) / \(settings.num(items.count))")
                        .font(.system(.footnote, design: .rounded, weight: .semibold))
                        .monospacedDigit()
                        .foregroundStyle(.secondary)
                        .contentTransition(.numericText())
                }
            }
            ToolbarItem(placement: .topBarTrailing) {
                if let c = current { DhikrToolbar(dhikr: c) }
            }
        }
        .sensoryFeedback(.selection, trigger: selected)
    }
}

// MARK: - Favourites

struct FavoritesView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var store: AdhkarStore
    @Environment(\.colorScheme) private var scheme
    @Namespace private var ns

    var body: some View {
        let p = settings.palette(scheme)
        let favs = store.items.filter { store.isFavorite($0) }
        NavigationStack {
            ZStack {
                SkyBackground(color1: .pink, color2: .purple)
                if favs.isEmpty {
                    VStack(spacing: 14) {
                        Image(systemName: "heart")
                            .font(.system(size: 54, weight: .light))
                            .foregroundStyle(.pink)
                            .symbolEffect(.pulse)
                        Text(settings.t("empty.fav"))
                            .font(.ui(.callout)).foregroundStyle(p.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 40)
                    }
                } else {
                    ScrollView {
                        LazyVStack(spacing: 12) {
                            ForEach(favs) { d in
                                if let c = store.category(d.cat) {
                                    NavigationLink(value: d) { DhikrRow(dhikr: d, category: c) }
                                        .buttonStyle(PressableStyle())
                                        .matchedTransitionSource(id: d.id, in: ns)
                                }
                            }
                        }
                        .padding(18)
                    }
                    .scrollIndicators(.hidden)
                }
            }
            .navigationTitle(settings.t("home.favorites"))
            .toolbarBackground(.hidden, for: .navigationBar)
            .navigationDestination(for: Dhikr.self) { d in
                DetailPager(items: favs, selected: d.id)
                    .navigationTransition(.zoom(sourceID: d.id, in: ns))
            }
        }
    }
}

// MARK: - Search

struct SearchView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var store: AdhkarStore
    @Environment(\.colorScheme) private var scheme
    @State private var query = ""
    @Namespace private var ns

    /// Removes Arabic diacritics so «الكرسي» matches «ٱلْكُرْسِيِّ».
    private func fold(_ s: String) -> String {
        let marks = CharacterSet(charactersIn: "\u{0610}"..."\u{061A}")
            .union(CharacterSet(charactersIn: "\u{064B}"..."\u{065F}"))
            .union(CharacterSet(charactersIn: "\u{0670}"))
            .union(CharacterSet(charactersIn: "\u{06D6}"..."\u{06ED}"))
        let cleaned = s.unicodeScalars.filter { !marks.contains($0) }
        return String(String.UnicodeScalarView(cleaned))
            .replacingOccurrences(of: "ٱ", with: "ا")
            .replacingOccurrences(of: "أ", with: "ا")
            .replacingOccurrences(of: "إ", with: "ا")
            .replacingOccurrences(of: "آ", with: "ا")
            .lowercased()
    }

    private var results: [Dhikr] {
        let q = fold(query.trimmingCharacters(in: .whitespaces))
        guard !q.isEmpty else { return store.items }
        return store.items.filter {
            fold($0.title).contains(q) || fold($0.text).contains(q) ||
            fold($0.fr).contains(q) || fold($0.source).contains(q)
        }
    }

    var body: some View {
        let p = settings.palette(scheme)
        NavigationStack {
            ZStack {
                SkyBackground()
                ScrollView {
                    LazyVStack(spacing: 12) {
                        if results.isEmpty {
                            Text(settings.t("empty.search")).foregroundStyle(p.secondary).padding(.top, 60)
                        }
                        ForEach(results) { d in
                            if let c = store.category(d.cat) {
                                NavigationLink(value: d) { DhikrRow(dhikr: d, category: c) }
                                    .buttonStyle(PressableStyle())
                                    .matchedTransitionSource(id: d.id, in: ns)
                            }
                        }
                    }
                    .padding(18)
                }
                .scrollIndicators(.hidden)
            }
            .navigationTitle(settings.t("tab.search"))
            .toolbarBackground(.hidden, for: .navigationBar)
            .searchable(text: $query, prompt: settings.t("home.search"))
            .navigationDestination(for: Dhikr.self) { d in
                DetailPager(items: results, selected: d.id)
                    .navigationTransition(.zoom(sourceID: d.id, in: ns))
            }
        }
    }
}
