import SwiftUI
import UIKit

// MARK: - Sleep Flow
// A full-screen, one-dhikr-per-page vertical feed. Swipe up (or finish counting) to move on.
// The sky changes colour with each category and slowly darkens as you progress, ending in "good night".

struct FlowView: View {
    let items: [Dhikr]

    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var store: AdhkarStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var scheme
    @State private var position: String?
    @State private var finished = false

    private static let endID = "flow.end"

    private var index: Int {
        guard let pos = position, let i = items.firstIndex(where: { $0.id == pos }) else {
            return position == Self.endID ? items.count : 0
        }
        return i
    }
    private var progress: Double { items.isEmpty ? 1 : min(1, Double(index) / Double(items.count)) }
    private var currentCategory: DhikrCategory? {
        let i = min(index, max(0, items.count - 1))
        return items.indices.contains(i) ? store.category(items[i].cat) : nil
    }

    var body: some View {
        ZStack {
            SkyBackground(color1: currentCategory?.color1 ?? .indigo,
                          color2: currentCategory?.color2 ?? .purple,
                          dim: finished ? 1 : progress * 0.9)

            ScrollView(.vertical) {
                LazyVStack(spacing: 0) {
                    ForEach(items) { d in
                        DhikrCardView(dhikr: d, showCategory: true) {
                            advance(from: d)
                        }
                        .containerRelativeFrame(.vertical)
                        .id(d.id)
                        .scrollTransition(axis: .vertical) { content, phase in
                            content
                                .opacity(1 - abs(phase.value) * 0.75)
                                .scaleEffect(1 - abs(phase.value) * 0.09)
                                .blur(radius: abs(phase.value) * 8)
                        }
                    }
                    GoodNightPage(onClose: { dismiss() })
                        .containerRelativeFrame(.vertical)
                        .id(Self.endID)
                }
                .scrollTargetLayout()
            }
            .scrollTargetBehavior(.paging)
            .scrollPosition(id: $position)
            .scrollIndicators(.hidden)
            .scrollBounceBehavior(.basedOnSize)

            // Comfort dimming that grows as the night goes on.
            Color.black.opacity(0.32 * progress).ignoresSafeArea().allowsHitTesting(false)

            overlayChrome
        }
        .preferredColorScheme(settings.preferredScheme ?? .dark)
        .onAppear {
            position = items.first?.id
            UIApplication.shared.isIdleTimerDisabled = true
        }
        .onDisappear { UIApplication.shared.isIdleTimerDisabled = false }
        .onChange(of: position) { _, new in
            if new == Self.endID, !finished {
                finished = true
                store.completeNight()
            }
        }
        .sensoryFeedback(.selection, trigger: position)
        .environment(\.layoutDirection, settings.layoutDirection)
    }

    // MARK: Chrome (close, progress, hint)

    private var overlayChrome: some View {
        VStack(spacing: 0) {
            HStack(spacing: 14) {
                Button { dismiss() } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 38, height: 38)
                        .background(.ultraThinMaterial, in: Circle())
                }
                .accessibilityLabel(settings.t("flow.close"))

                ProgressBar(value: progress)
                    .frame(height: 5)

                Text("\(settings.num(min(index + 1, items.count))) / \(settings.num(items.count))")
                    .font(.system(.footnote, design: .rounded, weight: .semibold))
                    .monospacedDigit()
                    .foregroundStyle(.white.opacity(0.85))
                    .contentTransition(.numericText())
            }
            .padding(.horizontal, 18)
            .padding(.top, 8)

            Spacer()

            if index < items.count {
                HintChevron(text: settings.t("flow.next"))
                    .padding(.bottom, 14)
                    .transition(.opacity)
            }
        }
        .animation(.snappy, value: index)
    }

    // MARK: Logic

    private func advance(from d: Dhikr) {
        guard settings.autoAdvance, let i = items.firstIndex(where: { $0.id == d.id }) else { return }
        let nextID = i + 1 < items.count ? items[i + 1].id : Self.endID
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.65) {
            withAnimation(.smooth(duration: 0.7)) { position = nextID }
        }
    }
}

// MARK: - Pieces

private struct ProgressBar: View {
    let value: Double
    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Capsule().fill(.white.opacity(0.2))
                Capsule().fill(.white.opacity(0.9))
                    .frame(width: max(5, geo.size.width * value))
                    .animation(.smooth, value: value)
            }
        }
    }
}

private struct HintChevron: View {
    let text: String
    @State private var up = false
    var body: some View {
        VStack(spacing: 2) {
            Image(systemName: "chevron.compact.up").font(.system(size: 26, weight: .semibold))
                .offset(y: up ? -5 : 3)
            Text(text).font(.ui(.caption, weight: .medium))
        }
        .foregroundStyle(.white.opacity(0.55))
        .onAppear { withAnimation(.easeInOut(duration: 1.1).repeatForever(autoreverses: true)) { up = true } }
        .allowsHitTesting(false)
    }
}

private struct MoonState {
    var y: CGFloat = 90
    var scale: CGFloat = 0.55
    var opacity: Double = 0
    var rotation: Double = -14
}

struct GoodNightPage: View {
    var onClose: () -> Void
    @EnvironmentObject private var settings: AppSettings

    var body: some View {
        VStack(spacing: 22) {
            Spacer()
            KeyframeAnimator(initialValue: MoonState(), repeating: false) { s in
                Image(systemName: "moon.stars.fill")
                    .symbolRenderingMode(.palette)
                    .foregroundStyle(Color(hex: "#FFE9A8"), Color(hex: "#B9B6FF"))
                    .font(.system(size: 92))
                    .shadow(color: Color(hex: "#7d7aff").opacity(0.6), radius: 30)
                    .scaleEffect(s.scale)
                    .offset(y: s.y)
                    .opacity(s.opacity)
                    .rotationEffect(.degrees(s.rotation))
            } keyframes: { _ in
                KeyframeTrack(\.y) { CubicKeyframe(0, duration: 1.8) }
                KeyframeTrack(\.scale) { SpringKeyframe(1.0, duration: 1.6, spring: .bouncy) }
                KeyframeTrack(\.opacity) { LinearKeyframe(1, duration: 0.9) }
                KeyframeTrack(\.rotation) { CubicKeyframe(0, duration: 1.8) }
            }
            Text(settings.t("flow.end.title"))
                .font(.ui(.largeTitle, weight: .bold)).foregroundStyle(.white)
            Text(settings.t("flow.end.sub"))
                .font(.ui(.title3)).foregroundStyle(.white.opacity(0.75))
                .multilineTextAlignment(.center)
            Spacer()
            Button(action: onClose) {
                Text(settings.t("flow.close"))
                    .font(.ui(.headline, weight: .semibold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 44).padding(.vertical, 14)
                    .background(.ultraThinMaterial, in: Capsule())
            }
            .buttonStyle(PressableStyle())
            .sensoryFeedback(.success, trigger: true)
            Text("\(settings.t("about.made")) \(settings.t("about.name"))")
                .font(.ui(.caption)).foregroundStyle(.white.opacity(0.4))
                .padding(.bottom, 30)
        }
        .padding(.horizontal, 28)
    }
}

// MARK: - Picker sheet (what goes into tonight's flow)

struct FlowPickerSheet: View {
    var onPick: ([Dhikr]) -> Void
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var store: AdhkarStore
    @Environment(\.colorScheme) private var scheme

    private static let shortTitles = [
        "آية الكرسي", "خواتيم البقرة (١)", "خواتيم البقرة (٢)", "سورة الإخلاص", "سورة الفلق", "سورة الناس",
        "عند وضع الجنب", "اللهم أسلمت نفسي", "تسبيح فاطمة", "اللهم قني عذابك", "سيد الاستغفار",
    ]

    private var shortFlow: [Dhikr] {
        Self.shortTitles.compactMap { t in store.items.first { $0.title.hasPrefix(t) } }
    }

    var body: some View {
        let p = settings.palette(scheme)
        ZStack {
            p.bg.ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    Text(settings.t("flow.choose"))
                        .font(.ui(.title2, weight: .bold)).foregroundStyle(p.label)
                        .padding(.top, 24).padding(.horizontal, 4)

                    optionRow(icon: "moon.stars.fill", c1: "#8e8cff", c2: "#5e5ce6",
                              title: settings.t("flow.short"), count: shortFlow.count) { onPick(shortFlow) }
                    optionRow(icon: "infinity", c1: "#ffc95e", c2: "#ff9f0a",
                              title: settings.t("flow.all"), count: store.items.count) { onPick(store.items) }

                    ForEach(store.categories) { c in
                        let list = store.items(in: c.id)
                        Button { onPick(list) } label: {
                            HStack(spacing: 14) {
                                CategoryTile(category: c, size: 38)
                                Text(settings.name(c)).font(.ui(.body, weight: .medium)).foregroundStyle(p.label)
                                Spacer()
                                Text(settings.num(list.count)).font(.ui(.subheadline)).foregroundStyle(p.secondary)
                            }
                            .padding(12).frame(maxWidth: .infinity).cardSurface(radius: 18)
                        }
                        .buttonStyle(PressableStyle())
                    }
                }
                .padding(.horizontal, 18).padding(.bottom, 30)
            }
        }
    }

    private func optionRow(icon: String, c1: String, c2: String, title: String, count: Int,
                           action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Image(systemName: icon).font(.system(size: 20, weight: .semibold)).foregroundStyle(.white)
                    .frame(width: 46, height: 46)
                    .background(LinearGradient(colors: [Color(hex: c1), Color(hex: c2)], startPoint: .topLeading, endPoint: .bottomTrailing),
                                in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                Text(title).font(.ui(.headline, weight: .bold)).foregroundStyle(.white)
                Spacer()
                Text(settings.num(count)).font(.system(.title3, design: .rounded, weight: .bold)).foregroundStyle(.white.opacity(0.9))
            }
            .padding(14).frame(maxWidth: .infinity)
            .background(LinearGradient(colors: [Color(hex: c1), Color(hex: c2)], startPoint: .topLeading, endPoint: .bottomTrailing),
                        in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .shadow(color: Color(hex: c2).opacity(0.4), radius: 14, y: 8)
        }
        .buttonStyle(PressableStyle())
    }
}
