# Fiche App Store (Français)
**Nom (≤30) :** Adhkâr du sommeil
**Sous-titre (≤30) :** Le flux de la nuit, hadiths sûrs
**Mots-clés (≤100) :** adhkar,sommeil,soir,coran,douaa,hadith,tasbih,musulman,nuit,prière,rappel
**Catégorie :** Style de vie (ou Référence)  |  **Âge :** 4+
**Description :**
Adhkâr du sommeil vous accompagne dans les dernières minutes de la journée, dans un design calme et fluide.

• Plus de 100 invocations, hadiths et versets, chacun avec sa source et son degré
• Flux du sommeil : glissez vers le haut, comptez d'un tap et regardez le ciel s'assombrir jusqu'à « Bonne nuit »
• Thèmes clair, sombre et nuit, couleur et taille du texte au choix
• Chiffres arabes ou occidentaux, interface en arabe et en français
• Rappel du soir, favoris et recherche rapide
• Sans compte, sans publicité, sans collecte de données

Créé par Zakaria Jabali.
